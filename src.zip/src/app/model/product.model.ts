


export interface Product{
    id? : number;
    name : string;
    features : string;
    count : number;
    price : number;
    type : string;

}