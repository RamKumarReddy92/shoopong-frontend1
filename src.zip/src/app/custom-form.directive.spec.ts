import { CustomFormDirective } from './custom-form.directive';

describe('CustomFormDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomFormDirective();
    expect(directive).toBeTruthy();
  });
});
